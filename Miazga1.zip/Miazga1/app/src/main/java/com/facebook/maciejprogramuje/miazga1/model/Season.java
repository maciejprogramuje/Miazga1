package com.facebook.maciejprogramuje.miazga1.model;

public class Season {
    int seasonNumber;

    public Season(int seasonNumber) {
        this.seasonNumber = seasonNumber;
    }

    public int getSeasonNumber() {
        return seasonNumber;
    }
}
